# Install Tailscale on a PiKVM

https://tailscale.com/blog/remote-access-with-pikvm-and-tailscale


[![Install Tailscale on a PiKVM](https://img.youtube.com/vi/Btqw56DFhro/maxresdefault.jpg)](https://www.youtube.com/embed/Btqw56DFhro?si=uZ8JDu488OEmJjMJ)


The YAML file in this directory should be modified according to your needs and placed in `/etc/kvmd/override.yaml`. More details can be found in the upstream [docs](https://docs.pikvm.org/first_steps/).