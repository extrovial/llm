# Tailscale YouTube supporting code snippets

Welcome to this repo which provides supporting code snippets for [Tailscale](https://tailscale.com/yt) YouTube videos.