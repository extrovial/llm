

## Get SSH key ID number

```
$ doctl -t dop_v1_d912349ce88 compute ssh-key list

ID          Name          FingerPrint
41133189    laptop        d0:3b:39:f0:61:f7:f5:ad:9a:d9:ee:44:92:09:5f:34
22222222    dev           2a:ad:9a:d9:ca:9c:77:ee:44:92:09:5f:3f:a7:6f:da
```